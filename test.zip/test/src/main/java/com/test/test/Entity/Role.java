package com.test.test.Entity;

public enum Role {
	USER,
	ADMIN,
	EMPLOYEE
}
